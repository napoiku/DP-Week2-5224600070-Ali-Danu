#pragma once
#include <IGenerateHand.h>
#include <iostream>

class SimpleGenerate : IGenerateHand {
    int generate () override {
        return 2;
    }
};