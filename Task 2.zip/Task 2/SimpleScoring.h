#pragma once
#include <IScoringSystem.h>

class SimpleScoring : public IScoringSystem {
public:
    int calculateScore(const std::vector<std::string>& chosenCards) override {
        // Logika sederhana: setiap kartu bernilai 10 poin
        return chosenCards.size() * 10;
    }
};