#pragma once

class IRewardSystem {
public:
    virtual ~IRewardSystem() {}
    // Menghitung berapa uang yang didapat berdasarkan hasil win/lose
    virtual int calculateMoneyReward(bool isWin, int round) = 0;
};